
import gspread
from oauth2client.service_account import ServiceAccountCredentials
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes, Update

def get_sheet():
    scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
    creds = ServiceAccountCredentials.from_json_keyfile_name("creds.json", scope)
    client = gspread.authorize(creds)
    sheet = client.open("TikTokLinks").sheet1
    return sheet

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("👋 স্বাগতম! TikTok লিংক সাবমিট করতে /submit দিন।")

async def submit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("⚠️ লিংক দিন! যেমন: /submit https://tiktok.com/@username")
        return

    user_link = context.args[0]
    sheet = get_sheet()
    links = sheet.col_values(1)

    if user_link not in links:
        sheet.append_row([user_link])

    previous_links = links[-100:]
    message = "✅ নিচের ১০০ জনকে TikTok-এ ফলো করুন:\n\n"
    for i, link in enumerate(previous_links):
        message += f"{i+1}. {link}\n"

    await update.message.reply_text(message)

# Your provided Telegram Bot Token
TOKEN = "7301381440:AAGvKaGNJLR-V2wiMWfjodfL9XShnI-CYzY"

app = ApplicationBuilder().token(TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("submit", submit))
app.run_polling()
